#ifndef FILE_HANDLER_H
#define FILE_HANDLER_H

#include "file_system.h"

//extern typedef struct inode;


void write_inode(int block_num, inode the_inode);

#endif

