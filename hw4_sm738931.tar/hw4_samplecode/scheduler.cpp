#include "scheduler.h"
#include "queues.h"

bool cpuBusy = false;

int totalWait = 0;
int processesStarted = 0; //if a job is blocked, it counts twice.
int maxWait = 0;

int new_arrival_for_block = 0;

//Simply used for statistics reporting
double getAvgWait()
{
	return (double) totalWait / processesStarted;
}

//Routine triggered once per quantum (on simulated clock interrupt) to determine which
//process gets CPU time and maintains queues
int scheduler()
{
	int i;

	//cpu needs to be free to dispatch.....
	if(cpuBusy == false && readyq != NULL)
	{
		my_queue* head = popQ(&readyq, &ready_tail);

               // updateState(head);
                dispatch(&head);
                cpuBusy = false;
	}

}


// This routine adds the specified task to the Processing queue.
// Maintaining FCFS philosophy, it is added to end
void dispatch(my_queue** t) {

	my_queue* task = *t;

        cpuBusy = true;	// CPU is set to BUSY
        updateState(task);       //Calling updateState() function

	//update Statistics
	int waitTime = cpuTimer - (task->this_task.arrival_time);
	totalWait+=waitTime;
	processesStarted++;
	if (waitTime > maxWait)
		maxWait = waitTime;

	*t = task;
}
//This routine updates the process states in the PCB (Process Control Block)
//Queues are updated maintaining FCFS philosophy
void updateState(my_queue* task)
{
	int est_running_time = task->this_task.est_runtime - 1; 		//est_runtime minus 1 to compare the running time of the processes
	int process_state = task->this_task.state;
	int task_id = task->this_task.taskid;

	if(task->this_task.time_run == est_running_time)			//Comparing the run time with est_running_time
   	{	
        	cout << cpuTimer << " |  RUNNING: " << task_id << " runTime: " << task->this_task.time_run << endl;
     		process_state = TERMINATED;						//Process state set to Terminated (5)
        	cout << cpuTimer << " |  TERMINATED TASK: " << task_id << endl;
    	}
	else if(task->this_task.time_run < est_running_time)			//Comparing the run time with est_running_time for less value
    	{
        	process_state = RUNNING;						//Process state set to RUNNING (1)
        	cout << cpuTimer << " |  RUNNING: " << task_id << " runTime: " << task->this_task.time_run << endl;
		task->this_task.time_run = task->this_task.time_run + 1;	//Incrementing the time run 
		process_state = READY;						//Process state set to READY
		if(task->this_task.time_run == task->this_task.block_startTime)
        	{
            		process_state = BLOCKED;				//Process state set to BLOCKED
            		cout << cpuTimer << " | BLOCK TASK: " << task_id << endl;
            		cout << "BLOCK WAIT TIME: " << task->this_task.block_waitTime << endl;
			new_arrival_for_block =  task->this_task.block_waitTime + cpuTimer;	//Calculating new arrival time for Blocked process
            		processing_head = task;				//Storing the blocked process in processing head to use it after completion of block time  
        	}                  
        	if(process_state == READY)					//If Process State is READY, then the process is added to the Ready Queue
            		pushQ(&readyq, &task, &ready_tail);  
        	if(cpuTimer == new_arrival_for_block)				//If this condition is satisfied, then the process is added to the Job Queue
		{
			//processing_head = NULL;
			pushQ(&jobq, &processing_head, &job_tail);
			processing_head = NULL;
		}
    	}
}
