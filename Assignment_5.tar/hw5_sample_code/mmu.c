//CPU sends Virtual Addresses to MMU
//MMU sends Physical Addresses to Memory

#include "mmu.h"
#include "memory.h"


int hits = 0;
int faults = 0;


//Find the index of the page table, based on a virtual address
int getVirtualPage(int virtualAddr)
{
	int i;
    	for(i = 0; i < virtualPages; i++)
	{
		if(pageTable[i].pageFrame ==virtualAddr){
			return i;
		}
	}
	// Page Not found in Virtual Memory
	return -1; 
}

//Convert a Virtual Address to a Physical Page. Returns -1 for a page fault
int getPhysicalPage(int virtualAddr)
{
	int pos = getVirtualPage(virtualAddr);


	if(pos==-1){		
		// Virtual Addrs Not Found
		fault_handler(virtualAddr);
		return -1;	
	}else{
		// Virtual Addrs in MMU
		my_queue* page = findPageByVirtualAddr(&memoryQ,pos);
      	        if(NULL!=page){
			// Page Found in Actual Memory
			hit(virtualAddr);
			return page->page;                            
       	        }else{
			// Page Fault in Actual Memory
			fault_handler(virtualAddr);
			return -1;
		}			
	}
}

//Convert a virtual address into a physical address
int getPhysicalAddress(int virtualAddr)
{
	int physical_page = getPhysicalPage(virtualAddr);
	return physical_page + (virtualAddr % pageSize);
}


// Access Memory: Given the virtual address, access the page in memory. Returns the physical address 
int access(int virtualAddr)
{
	int physicalAddr = getPhysicalAddress(virtualAddr);
	return physicalAddr;
}


//Page was found in memory.  Update the queue - Move accessed page to tail to maintain LRU order.
void hit(int virtualAddr)
{
	int pos = getVirtualPage(virtualAddr);
	
	// find Page from Actual Memory
	my_queue* page = findPageByVirtualAddr(&memoryQ,pos);

	// Update Position, As recently used
	moveToTail(&memoryQ, &page,&memoryQ_tail);
	
	reportChange(true, virtualAddr, page->page, -1);

	// Increment Hits
	hits++;
}


//Page Fault has occurred.  Trap to the OS and handle page fault.
void fault_handler(int virtualAddr)
{        	
	int pos = getVirtualPage(virtualAddr);
	if(pos==-1){
		// Not Found in Virtual Addrs
		int i=0;
		for(i = 0; i < virtualPages; i++)
		{
			if(pageTable[i].pageFrame == -1){
				pageTable[i].pageFrame = virtualAddr;
				break;
			}
		}
		pos=i;
	}
	
	// Get Least REcently used Page
	my_queue* oldest_page = memoryQ;
       	removeQ(&memoryQ, &oldest_page,&memoryQ_tail);
	
	// Add new Page at the end of page queue
	struct my_queue *new_node = (struct my_queue*) malloc(sizeof(struct my_queue));
	new_node->page = oldest_page->page; 
	new_node->virtual_page = pos;
	pushQ(&memoryQ,&new_node,&memoryQ_tail);     	
	
	reportChange(false, virtualAddr, oldest_page->page, oldest_page->virtual_page);

	// Increment Faults
	faults++;
 }

 
 //Used for outputing to standard out.   You do not need to edit this function, but you will likely want to call it. 
 //The purpose of this function is to make it easy to output information to the console
 void reportChange(bool hit, int virtualAddr, int physical_page, int removed_page)
 {
	char *s0 = cat("Address = ", itoa(virtualAddr));
	char *s1 = "";
	if (hit)
		s1 = cat(" | HIT! Virtual Page=",itoa(getVirtualPage(virtualAddr)));
	else
		s1 = cat(" | PAGE FAULT! Virtual Page=",itoa(getVirtualPage(virtualAddr)));
	char *s2 = cat(" is in physical page=", itoa(physical_page));
	char *s3 = "";
	if (!hit)
		s3 = cat(" | removed virtual page: ",itoa(removed_page));
	print(NOTIFY,cat( cat(s0,s1), cat(s2,s3) ));
 }
