/**
 * A kernel module for controlling a GPIO LED/button pair. 
 * The device mounts devices via sysfs /sys/class/gpio/gpio115 and gpio49. 
 * Therefore, this test LKM circuit assumes that an LED is attached to
 * GPIO 49 which is on P9_23 and the button is attached to GPIO 115 on 
 * P9_27. 
*/

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/gpio.h>       // Required for the GPIO functions
#include <linux/interrupt.h>  // Required for the IRQ code
#include <asm/uaccess.h>
#include <linux/mutex.h>
#include <linux/device.h>         // Header to support the kernel Driver Model
#include <linux/fs.h>             // Header for the Linux file system support
#define  CLASS_NAME  "char"
#define  DEVICE_NAME "leddriver"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Shivika Malik");
MODULE_DESCRIPTION("A Button/LED test driver for the BBB");
MODULE_VERSION("1.0");

static unsigned int gpioYELLOW = 60;       ///< hard coding the LED - YELLOW gpio for this example to P9_12 (GPIO60)
static unsigned int gpioGREEN = 48;       ///< hard coding the LED - GREEN gpio for this example to P9_15 (GPIO48)
static unsigned int gpioRED = 49;       ///< hard coding the LED - RED gpio for this example to P9_23 (GPIO49)
static unsigned int gpioWHITE = 112;       ///< hard coding the LED - WHITE gpio for this example to P9_30 (GPIO112)

static unsigned int gpioButton = 115;   ///< hard coding the button gpio for this example to P9_27 (GPIO115)
static unsigned int irqNumber;          ///< Used to share the IRQ number within this file
static bool	    ledOn = 0;          ///< Is the LED on or off? Used to invert its state (off by default)

static int    deviceNumber;                  /// Stores the device number -- determined automatically
static char   message[256] = {0};           /// Memory for the string that is passed from userspace
static short  size_of_message;              /// Used to remember the size of the string stored
static int    numberOpens = 0;              /// Counts the number of times the device is opened
static struct class*  driverClass  = NULL; /// The struct pointer for device-driver class 
static struct device* driverDevice = NULL; /// The struct pointer for device-driver device

static DEFINE_MUTEX(driver_mutex); 
static int result;

/// Function prototype for the custom IRQ handler function -- see below for the implementation
static irq_handler_t  ebbgpio_irq_handler(unsigned int irq, void *dev_id, struct pt_regs *regs);

/** @brief The LKM initialization function
 *  The static keyword restricts the visibility of the function to within this C file. The __init
 *  macro means that for a built-in driver (not a LKM) the function is only used at initialization
 *  time and that it can be discarded and its memory freed up after that point. In this example this
 *  function sets up the GPIOs and the IRQ
 *  @return returns 0 if successful
 */
 
static irq_handler_t  ebbgpio_irq_handler(unsigned int irq, void *dev_id, struct pt_regs *regs);
static int dev_open(struct inode *, struct file *);
static int dev_release(struct inode *, struct file *);
static ssize_t dev_read(struct file *, char *, size_t, loff_t *);
static ssize_t dev_write(struct file *, const char *, size_t, loff_t *);

static struct file_operations fops =		// Function for Kernel
{
   .open = dev_open,
   .read = dev_read,
   .write = dev_write,
   .release = dev_release,
};

static int __init ebbgpio_init(void){
   int result = 0;
   printk(KERN_INFO "GPIO_TEST: Initializing the GPIO_TEST LKM.\n");
   deviceNumber = register_chrdev(0, DEVICE_NAME, &fops);
   if (deviceNumber<0){
      printk(KERN_ALERT "KDriver failed to register a Device number !!\n");
      return deviceNumber;
   }
    // To register the Device Class
   driverClass = class_create(THIS_MODULE, CLASS_NAME);
   if (IS_ERR(driverClass)){                // Checking and cleaning up if there is an error
      unregister_chrdev(deviceNumber, DEVICE_NAME);
      printk(KERN_ALERT "Failed to register device class !!\n");
      return PTR_ERR(driverClass);          // Correct way to return an error on a pointer
   }
   // Register the Device Driver
   driverDevice = device_create(driverClass, NULL, MKDEV(deviceNumber, 0), NULL, DEVICE_NAME);
   if (IS_ERR(driverDevice)){               // Clean it up if there is an error
      class_destroy(driverClass);          
      unregister_chrdev(deviceNumber, DEVICE_NAME);
      printk(KERN_ALERT "Failed to create the device !!\n");
      return PTR_ERR(driverDevice);
   }
   
   // Is the GPIO a valid GPIO number (e.g., the BBB has 4x32 but not all available)
   mutex_init(&driver_mutex);
  
   if (!gpio_is_valid(gpioYELLOW)){
      printk(KERN_INFO "GPIO_TEST: invalid YELLOW LED GPIO.\n");
      return -ENODEV;
   }
   if (!gpio_is_valid(gpioRED)){
      printk(KERN_INFO "GPIO_TEST: invalid RED LED GPIO.\n");
      return -ENODEV;
   }
   if (!gpio_is_valid(gpioGREEN)){
      printk(KERN_INFO "GPIO_TEST: invalid GREEN LED GPIO.\n");
      return -ENODEV;
   }
   if (!gpio_is_valid(gpioWHITE)){
      printk(KERN_INFO "GPIO_TEST: invalid WHITE LED GPIO.\n");
      return -ENODEV;
   }
   // Going to set up the LED. It is a GPIO in output mode and will be on by default
   ledOn = true;
   gpio_request(gpioYELLOW, "sysfs");          // gpioLED is hardcoded to 60, request it
   gpio_direction_output(gpioYELLOW, ledOn);   // Set the gpio to be in output mode and on
   gpio_export(gpioYELLOW, false);             // Causes gpio60 to appear in /sys/class/gpio
   
   gpio_request(gpioRED, "sysfs");          // gpioLED is hardcoded to 49, request it
   gpio_direction_output(gpioRED, ledOn);   // Set the gpio to be in output mode and on
   gpio_export(gpioRED, false);             // Causes gpio49 to appear in /sys/class/gpio
   
   gpio_request(gpioGREEN, "sysfs");          // gpioLED is hardcoded to 48, request it
   gpio_direction_output(gpioGREEN, ledOn);   // Set the gpio to be in output mode and on
   gpio_export(gpioGREEN, false);             // Causes gpio48 to appear in /sys/class/gpio
   
   gpio_request(gpioWHITE, "sysfs");          // gpioLED is hardcoded to 112, request it
   gpio_direction_output(gpioWHITE, ledOn);   // Set the gpio to be in output mode and on
   gpio_export(gpioWHITE, false);             // Causes gpio112 to appear in /sys/class/gpio

   gpio_request(gpioButton, "sysfs");       // Set up the gpioButton
   gpio_direction_input(gpioButton);        // Set the button GPIO to be an input
   gpio_set_debounce(gpioButton, 200);      // Debounce the button with a delay of 200ms
   gpio_export(gpioButton, false);          // Causes gpio115 to appear in /sys/class/gpio
			                  
// the bool argument prevents the direction from being changed

   // Perform a quick test to see that the button is working as expected on LKM load
   printk(KERN_INFO "GPIO_TEST: The button state is currently: %d\n", gpio_get_value(gpioButton));

   // GPIO numbers and IRQ numbers are not the same! This function performs the mapping for us
   irqNumber = gpio_to_irq(gpioButton);
   printk(KERN_INFO "GPIO_TEST: The button is mapped to IRQ: %d\n", irqNumber);

   // This next call requests an interrupt line
   result = request_irq(irqNumber,             // The interrupt number requested
                        (irq_handler_t) ebbgpio_irq_handler, // The pointer to the handler function below
                        IRQF_TRIGGER_RISING,   // Interrupt on rising edge (button press, not release)
                        "ebb_gpio_handler",    // Used in /proc/interrupts to identify the owner
                        NULL);                 // The *dev_id for shared interrupt lines, NULL is okay

   printk(KERN_INFO "GPIO_TEST: The interrupt request result is: %d\n", result);
   return result;
}

/** @brief The LKM cleanup function
 *  Similar to the initialization function, it is static. The __exit macro notifies that if this
 *  code is used for a built-in driver (not a LKM) that this function is not required. Used to release the
 *  GPIOs and display cleanup messages.
 */
static void __exit ebbgpio_exit(void){
	
	//Existence of the device 
   mutex_destroy(&driver_mutex);                           // destroy the mutex
   device_destroy(driverClass, MKDEV(deviceNumber, 0));    // To remove the device
   class_unregister(driverClass);                          // To unregister the device class
   class_destroy(driverClass);                             // To remove the device class
   unregister_chrdev(deviceNumber, DEVICE_NAME);
   
   printk(KERN_INFO "GPIO_TEST: The button state is currently: %d\n", gpio_get_value(gpioButton));
   gpio_set_value(gpioYELLOW, 0);	// Turn the YELLOW LED off, makes it clear the device was unloaded
   gpio_unexport(gpioYELLOW);           // Unexport the YELLOW LED GPIO
   
   gpio_set_value(gpioRED, 0);          // Turn the RED LED off, makes it clear the device was unloaded
   gpio_unexport(gpioRED);              // Unexport the RED LED GPIO
   
   gpio_set_value(gpioGREEN, 0);        // Turn the GREEN LED off, makes it clear the device was unloaded
   gpio_unexport(gpioGREEN);            // Unexport the GREEN LED GPIO
   
   gpio_set_value(gpioWHITE, 0);        // Turn the WHITE LED off, makes it clear the device was unloaded
   gpio_unexport(gpioWHITE);		// Unexport the WHITE LED GPIO
   
   free_irq(irqNumber, NULL);           // Free the IRQ number, no *dev_id required in this case
   gpio_unexport(gpioButton);           // Unexport the Button GPIO
   gpio_free(gpioYELLOW);               // Free the YELLOW LED GPIO
   gpio_free(gpioRED);                  // Free the RED LED GPIO
   gpio_free(gpioGREEN);                // Free the GREEN LED GPIO
   gpio_free(gpioWHITE);                // Free the WHITE LED GPIO
   gpio_free(gpioButton);               // Free the Button GPIO
   
printk(KERN_INFO "GPIO_TEST: Goodbye from the LKM!\n");
}

/** @brief The GPIO IRQ Handler function
 *  This function is a custom interrupt handler that is attached to the GPIO above. The same interrupt
 *  handler cannot be invoked concurrently as the interrupt line is masked out until the function is complete.
 *  This function is static as it should not be invoked directly from outside of this file.
 *  @param irq    the IRQ number that is associated with the GPIO -- useful for logging.
 *  @param dev_id the *dev_id that is provided -- can be used to identify which device caused the interrupt
 *  Not used in this example as NULL is passed.
 *  @param regs   h/w specific register values -- only really ever used for debugging.
 *  return returns IRQ_HANDLED if successful -- should return IRQ_NONE otherwise.
 */

static irq_handler_t ebbgpio_irq_handler(unsigned int irq, void *dev_id, struct pt_regs *regs){
   ledOn = !ledOn;                          	// Invert the LED state on each button press
   gpio_set_value(gpioYELLOW, ledOn);          	// Set the physical YELLOW LED accordingly
   gpio_set_value(gpioRED, ledOn);          	// Set the physical RED LED accordingly
   gpio_set_value(gpioGREEN, ledOn);          	// Set the physical GREEN LED accordingly
   gpio_set_value(gpioWHITE, ledOn);          	// Set the physical WHITE LED accordingly
   printk(KERN_INFO "GPIO_TEST: Interrupt! (button state is %d)\n", gpio_get_value(gpioButton));
   return (irq_handler_t) IRQ_HANDLED;      	// Announce that the IRQ has been handled correctly
}

//Function to Open the device
static int dev_open(struct inode *inodep, struct file *filep){
   numberOpens++;
   printk(KERN_INFO "KDriver: Device has been opened %d time(s)\n", numberOpens);

   mutex_lock(&driver_mutex);                             //lock the mutex

   return 0;
}

// Function for Releasing the device
static int dev_release(struct inode *inodep, struct file *filep){

   mutex_unlock(&driver_mutex);                      //unlock the mutex

   printk(KERN_INFO "KDriver: Device successfully closed\n");
   return 0;
}

//Function to Read to the device
static ssize_t dev_read(struct file *filep, char *buffer, size_t len, loff_t *offset){
   int error_count = 0;
   // copy_to_user has the format ( * to, *from, size) and returns 0 on success
   error_count = copy_to_user(buffer, message, size_of_message);

   if (error_count==0){            	// Success, if true.
      printk(KERN_INFO "KDriver: Sent %d characters to the user\n", size_of_message);
      return (size_of_message=0);  	// clear the position to the start and return 0
   }
   else {
      printk(KERN_INFO "KDriver: Failed to send %d characters to the user\n", error_count);
      return -EFAULT;             	// Returning -14 as bad address message
   }
}

//Function to Turn ON and Turn OFF the LEDs
static ssize_t dev_write(struct file *filep, const char *buffer, size_t len, loff_t *offset){

   ledOn=true;
   sprintf(message, "%s(%zu letters)", buffer, len);   	// Appending the received string with its length
   if (message[0]=='0'){
   	gpio_set_value(gpioYELLOW, 0);              	// Turn the YELLOW LED off, makes it clear the device was unloaded
        gpio_unexport(gpioYELLOW);
   }
   else{
   	gpio_direction_output(gpioYELLOW, ledOn);	// Turn the YELLOW LED on, makes it clear the device was loaded
   	gpio_export(gpioYELLOW, false); 
   }
   if (message[1]=='0'){
   	gpio_set_value(gpioGREEN, 0);             	// Turn the GREEN LED off, makes it clear the device was unloaded
    gpio_unexport(gpioGREEN);
   }
   else{
   	gpio_direction_output(gpioGREEN, ledOn);	// Turn the GREEN LED on, makes it clear the device was loaded
   	gpio_export(gpioGREEN, false); 
   }
   if (message[2]=='0'){
   	gpio_set_value(gpioRED, 0);              	// Turn the RED LED off, makes it clear the device was unloaded
    gpio_unexport(gpioRED);
   }
   else{
   	gpio_direction_output(gpioRED, ledOn);		// Turn the RED LED on, makes it clear the device was loaded
   	gpio_export(gpioRED, false); 
   }
   if (message[3]=='0'){
   	gpio_set_value(gpioWHITE, 0);              	// Turn the WHITE LED off, makes it clear the device was unloaded
    gpio_unexport(gpioWHITE);
   }
   else{
   	gpio_direction_output(gpioWHITE, ledOn);	// Turn the WHITE LED on, makes it clear the device was loaded
   	gpio_export(gpioWHITE, false); 
   }
   
   size_of_message = strlen(message);                 	// store the length of the stored message
   printk(KERN_INFO "KDriver: Received %zu characters from the user.\n", len);
   return len;
}

/// This next calls are  mandatory -- they identify the initialization function
/// and the cleanup function (as above).

module_init(ebbgpio_init);
module_exit(ebbgpio_exit);
