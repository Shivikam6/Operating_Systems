/*
* Original Code taken from Dereck Molloy (text: Exploring Beagle Board Black)
* Modified for this assignment by Shivika Malik
*/
#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
#include<pthread.h>
#define NUM_THREADS 2

#define BUFFER_LENGTH 256               ///< The buffer length (crude but fine)
static char receive[BUFFER_LENGTH];     ///< The receive buffer from the LKM

void *accessDriver(void *threadid)
{
  int str, file;
  char string[BUFFER_LENGTH];
  printf("Starting device test code example ..\n");
  file = open("/dev/kernelDriver",O_RDWR);    //To open the device with read & write access
  if (file < 0)
    perror("Failed to open the device !!");
 
 printf("Type in a short string to send to the Kernel module:\n");
 scanf("%[^\n]%*c", string); //Reading the typed String with spaces
 printf("Writing message to the device [%s].\n", string); // String that needs to be sent
 str = write(file, string, strlen(string)); //Sending the string to the LKM
 
  if(str < 0)
   perror("Failed to write the message to the device !!");
 
  printf("Press Enter to read back from the device ..\n");
  getchar();
 
  printf("Reading from the device ..\n");
  str = read(file, receive, BUFFER_LENGTH); //Read the response from the LKM
  if (str < 0)
   perror("Failed to read the message fom the device !!");
 
 printf("The received message is: [%s]\n", receive);

 int err = close(file); 		//Closing the device
 if (err < 0)
   perror("Error !! Closing the file.");

   pthread_exit(NULL);
}


int main(){

pthread_t threads[NUM_THREADS];
int create, t;
int i;
for(t=0;t<NUM_THREADS;t++)
{
printf("Creating the thread in the main function %ld\n",t);
create = pthread_create(&threads[t], NULL, accessDriver, (void *) t); //Creating the thread
if(create){
	printf("ERROR: return code from pthread_create() is %d\n", create);
	exit(1);
       }
}

for(i=0;i<NUM_THREADS;i++)
{
	pthread_join(threads[i], NULL);		//Causes threaad to wait for another thread to terminate efore proceeding
}

pthread_exit(NULL);
printf("End of the Program\n");
return 0;
}
